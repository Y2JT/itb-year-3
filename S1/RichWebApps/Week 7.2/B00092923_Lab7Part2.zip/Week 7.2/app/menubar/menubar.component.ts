// Implement MenuBarComponent here.
import {Component} from '@angular/core';

@Component({
    moduleId:     module.id,
    selector:    'osl-menubar', 
    templateUrl: 'menubar.component.html'
})
export default class MenuBarComponent {}