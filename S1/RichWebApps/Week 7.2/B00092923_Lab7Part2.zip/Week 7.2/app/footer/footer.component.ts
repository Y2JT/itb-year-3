// Implement FooterComponent here.
import {Component} from '@angular/core';

@Component({
    moduleId:     module.id,
    selector:    'osl-footer', 
    templateUrl: 'footer.component.html'
})
export default class FooterComponent {}