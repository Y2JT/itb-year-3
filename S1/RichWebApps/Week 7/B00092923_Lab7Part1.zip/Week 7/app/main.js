"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// App bootstrap.
var platform_browser_dynamic_1 = require("@angular/platform-browser-dynamic");
var ShoppingCart_1 = require("./ShoppingCart");
platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(ShoppingCart_1.AppModule);
//# sourceMappingURL=main.js.map