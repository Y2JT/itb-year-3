// App bootstrap.
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import {AppModule} from './ShoppingCart';

platformBrowserDynamic().bootstrapModule(AppModule);