/**
 * @(#)ListException.java
 * @Joseph Tierney
 * @version 1.00 2017/10/10
 */

public class ListException extends RuntimeException {
  public ListException(String s) {
    super(s);
  }//end constructor
}//end ListException