/**
 * @(#)StackException.java
 * @Joseph Tierney
 * @version 1.00 2017/10/19
 */

public class StackException extends java.lang.RuntimeException{
  public StackException(String s){
    super(s);
  }//end constructor
}//end StackException
