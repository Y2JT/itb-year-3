package zoo;

import zoo.Animal;
import zoo.alligator;

public class AlligatorAdapter extends Animal{

	protected void feed() {
		alligator snappy = new alligator(500);
		snappy.feedalligator();
	}

}