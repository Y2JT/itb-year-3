package com.filmApp.CommandPattern;

public interface CommandHolder {
	
	public void setCommand(Command comd);
	
	public Command getCommand();

}
