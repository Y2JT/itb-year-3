/**
 * Command
 */
package com.filmApp.CommandPattern;

public interface Command {
	
	public void Execute();

}
