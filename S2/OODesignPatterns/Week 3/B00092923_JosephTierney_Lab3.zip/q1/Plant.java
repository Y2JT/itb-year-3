public class Plant {
    private String name;
    public Plant(String pname) {
        name = pname;     //save name
    }
    public String getName() {
        return name;
    }
}

